#ifndef Room_h
#define Room_h

using namespace std;        //Using standard namespacing

class Room{

    public:

        Room();     //Our non parameterized constructor

        Room(string clues[], bool input_killed_here);       //Our parameterized constructor

        string get_clues();     //The getter that will return a random clue

        bool get_if_killed_in_room();       //The getter that will return if the murdered was killed in this room

        void set_killed_in_room(bool input_killed_here);        //The setter that will set if they were killed in this room

    private:

        string clues[10];       //The member array that will hold clues
        bool room_killed_in;        //The bool that flags if they were killed in this room

};

#endif