#include <iostream>
#include <string>
#include "Suspects.h"       //Including the header files we want to use
#include "Weapons.h"

using namespace std;

Suspect::Suspect(){
    is_the_killer = 0;      //Our non parameterized constructor that sets everything to blank or zero
    suspect_name = "";
}

    //Our parameterized constructor that sets everything to input
Suspect::Suspect(string input_suspect_name, string suspect_dialogue_clues[], bool input_is_the_killer, Weapon what_is_holding_input){
    is_the_killer = input_is_the_killer;
    what_is_holding = what_is_holding_input;
    suspect_name = input_suspect_name;
}

string Suspect::get_suspect_name(){     //our getter that returns the suspect name
    return suspect_name;
}

void Suspect::set_suspect_name(string input_suspect_name){  //Our setter that sets the suspect name to input
    suspect_name = input_suspect_name;
}


//string Suspect::get_suspect_dialogue(){
    //This function will return a random dialogue string depending on a random number chosen between 1 and 10.
    //Process: 1.Pick a number between 1 and 10 using the rand function
              //2. use this number as an index to select a string from the dialogue array
//}

bool Suspect::get_is_the_killer(){  //Our getter that returns if the suspect is the killer
    return is_the_killer;
}

void Suspect::set_is_the_killer(bool input_is_the_killer){  //Our setter that lets us set whether this subject is the killer
    is_the_killer = input_is_the_killer;
}

string Suspect::get_what_is_holding(){  //Our getter that gets the string name of the weapon object the suspect is holding
    string name = what_is_holding.get_weapon_name();
    return name;
}

void Suspect::set_what_is_holding(Weapon what_is_holding_input){        //Our setter that lets us set what weapon object the suspect is holding
    string name = what_is_holding_input.get_weapon_name();
    what_is_holding.set_weapon_name(name);
}