#include <iostream>
#include <string>
#include "Weapons.h"        //Including our header file

using namespace std;

Weapon::Weapon(){   //Our non parameterized constructor
    name = "";  
    is_killer_weapon = false;
}

    //The parameterized constructor that sets the variables to input
Weapon::Weapon(bool is_killer_weapon_input, string input_name){
    name = input_name;
    is_killer_weapon = is_killer_weapon_input;
}

string Weapon::get_weapon_name(){   //The getter that returns the weapon name
    return name;
}

void Weapon::set_weapon_name(string input_name){    //The setter that sets the weapon name to input
    name = input_name;
}

bool Weapon::is_the_killer(){   //The getter that shows if this is the weapon used to kill
    return is_killer_weapon;
}

void Weapon::set_is_killer_weapon(bool input_true_false){   //The setter thats sets if this is the weapon used to kill
    is_killer_weapon = input_true_false;
}