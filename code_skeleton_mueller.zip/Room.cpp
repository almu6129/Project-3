#include <iostream>
#include <string>
#include "Room.h"       //Including our header file

using namespace std;

Room::Room(){   //Our non parameterized constructor
    for(int i = 0; i <10; i++){     //The for loop that will fill the clues array with blank strings
        clues[i] = "";
    }
    room_killed_in = 0;     //Setting killed in room to false
}

Room::Room(string clues[], bool input_killed_here){     //Our parameterized constructor
    room_killed_in = input_killed_here;     //Setting if they were killed in this room to the user input
}

//string Room::get_clues(){
        //This function will return a random clue from the clues array
        //Process:
        //1.It will get a random number from 1-10 using the rand function
        //2.IT will use this number as an index to take a random clue from the clues array
//}


bool Room::get_if_killed_in_room(){     //The getter function that will return if they were killed in this room
    return room_killed_in;
}

void Room::set_killed_in_room(bool input_killed_here){  //The setter that will set if they were killed in this room to user input
    room_killed_in = input_killed_here;
}