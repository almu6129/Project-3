#include <iostream>
#include <string>
#include "Player.h" //Including the player header file

using namespace std;

Player::Player(){       //The non parameterized constructor that sets everything to blank and zero
    stamina_level = 0;
    intuition_level = 0;
    personability_level = 0;
    hardiness_level = 0;
    quick_recovery_level = 0;
    player_name = "";
    for(int i = 0; i<10; i++){
        suspects_investigated[i] = "";
    }
    for(int i = 0; i<10;i++){
        rooms_investigated[i] = "";
    }
}

    //The parameterized constructor that sets every member variable to the user input
Player::Player(int stamina_level_input, int intuition_level_input, int personability_level_input, int hardiness_level_input,
               int quick_recovery_level_input, string player_name_input, string suspects_investigated[], string rooms_investigated[]){

    stamina_level = stamina_level_input;
    intuition_level = intuition_level_input;
    personability_level = personability_level_input;
    hardiness_level = hardiness_level_input;
    quick_recovery_level = quick_recovery_level_input;
    player_name = player_name_input;

        }

int Player::get_stamina_level(){    //This getter function returns the level
    return stamina_level;
}

void Player::set_stamina(int stamina_level_input){  //The setter that sets the member variable to user input
    stamina_level = stamina_level_input;
}

int Player::get_intuition_level(){    //This getter function returns the level
    return intuition_level;
}

void Player::set_intuition(int intuition_level_input){  //The setter that sets the member variable to user input
    intuition_level = intuition_level_input;
}
        
int Player::get_personability_level(){    //This getter function returns the level
    return personability_level;
}

void Player::set_personability(int personability_level_input){  //The setter that sets the member variable to user input
    personability_level = personability_level_input;
}

int Player::get_hardiness_level(){    //This getter function returns the level
    return hardiness_level;
}

void Player::set_hardiness(int hardiness_level_input){  //The setter that sets the member variable to user input
    hardiness_level = hardiness_level_input;
}

int Player::get_quick_recovery_level(){    //This getter function returns the level
    return quick_recovery_level;
}

void Player::set_quick_recovery(int quick_recovery_level_input){  //The setter that sets the member variable to user input
    quick_recovery_level = quick_recovery_level_input;
}

string Player::get_player_name(){   //The getter function that returns the player name
    return player_name;
}

void Player::set_player_name(string player_name_input){  //The setter that sets the member variable to user input
    player_name = player_name_input;
}

